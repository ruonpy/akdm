import pygame
import random
import asyncio  # Required for web compatibility

pygame.init()

# We wrap everything inside an async function so the browser can handle the game loop properly.
async def main():
    # Screen setup
    screen = pygame.display.set_mode((600, 400))
    pygame.display.set_caption("Dodge the Falling Blocks")

    player_x = 250
    player_y = 350 
    falling_x = random.randint(0, 550)
    falling_y = 0

    score = 0
    font = pygame.font.SysFont(None, 36)
    clock = pygame.time.Clock()

    running = True
    while running:
        clock.tick(60)
        screen.fill((0, 0, 0))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and player_x > 0:
            player_x -= 5
        if keys[pygame.K_RIGHT] and player_x < 550:
            player_x += 5

        falling_y += 5

        # Creating Rect objects for collision detection
        player_rect = pygame.Rect(player_x, player_y, 50, 50)
        enemy_rect = pygame.Rect(falling_x, falling_y, 50, 50)

        # Reset falling object when it goes off screen
        if falling_y > 400:
            falling_y = 0
            falling_x = random.randint(0, 550)
            score += 1

        # Collision detection
        if player_rect.colliderect(enemy_rect):
            print("GAME OVER! Your Score:", score)
            running = False

        # Drawing shapes
        pygame.draw.rect(screen, (0, 255, 0), player_rect)
        pygame.draw.rect(screen, (255, 0, 0), enemy_rect)

        # Render score text
        text = font.render("Score: " + str(score), True, (255, 255, 255))
        screen.blit(text, (10, 10))

        pygame.display.update()
        
        # CRITICAL: This line yields control back to the browser execution loop.
        # Without this, the web page will crash/freeze.
        await asyncio.sleep(0)

    pygame.quit()

# This triggers the asynchronous execution of your game
asyncio.run(main())